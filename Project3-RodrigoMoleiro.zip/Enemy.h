#ifndef ENEMY_H
#define ENEMY_H

#include <iostream>

using namespace std;


class Player;

class Enemy 
{
    public:

        Enemy();
        Enemy(int x_in, int y_in, int health_in, int attack_in);

        int getX();
        int getY();
        int getHealth();
        int getAttack();
        
        string getName();

        void attackPlayer(Player player);
        

        void setHealth(int );
        void setName(string );

    private:

        int x;
        int y;


        int health;
        int attack = 10;

        string name;


};

#endif