#include "Item.h"
#include "Player.h"
#include <iostream>

using namespace std;


void Item::useItem(Player player) 
{
    // Must be overriden by child class
}


Item::Item()
{
    name = "";

}

Item::Item(string name_in, int x_in, int y_in) 
{
    name = name_in;
    x = x_in;
    y = y_in;
}

void Item::setName(string name_in)
{
    name = name_in;
}

string Item::getName()
{
    return name;
}

int Item::getX()
{
    return x;
}

int Item::getY() 
{
    return y;
}

void Item::setX(int x_in) 
{
    x = x_in;
}

void Item::setY(int y_in) 
{
    y = y_in;
}