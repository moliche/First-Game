#include "Weapon.h"

#include <iostream>


using namespace std;


Weapon::Weapon()
{
    name = "";
    damage = 10;
}

Weapon::Weapon(int x_in, int y_in, string name_in, int damage_in) 
{
    x = x_in;
    y = y_in;
    name = name_in;
    damage = damage_in;
}

void Weapon::setName(string name_in)
{
    name = name_in;
}

string Weapon::getName()
{
    return name;
}


int Weapon::getX() 
{
    return x;
}

int Weapon::getY() 
{
    return y;
}

void Weapon::setX(int x_in) 
{
    x = x_in;
}

void Weapon::setY(int y_in) 
{
    y = y_in;
}

int Weapon::getDamage()
{
    return damage;
}