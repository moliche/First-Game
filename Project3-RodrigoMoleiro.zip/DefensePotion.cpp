#include "DefensePotion.h"
#include <iostream>
#include <cstdlib>

using namespace std;

DefensePotion::DefensePotion(string name, int x, int y, int defenseBoost_in) : Item(name, x, y)
{
    defenseBoost = defenseBoost_in;
}

void DefensePotion::useItem(Player player) 
{
    player.setDefense(player.getDefense() + defenseBoost);
}