#ifndef ATTACKPOTION_H
#define ATTACKPOTION_H

#include <iostream>
#include "Item.h"
#include "Player.h"

using namespace std;


class AttackPotion : public Item
{
    public:

        AttackPotion(string name_in, int x, int y, int attackBoost);

        void useItem(Player player);

        

    private:
    
        int attackBoost;



};

#endif