------------------------
HOW TO COMPILE AND RUN
------------------------
Compile: g++ -std=c++17 game.cpp Enemy.cpp AttackPotion.cpp HealthPotion.cpp DefensePotion.cpp Player.cpp Map.cpp Weapon.cpp Item.cpp -o start
Run: ./start or ./a.out 
------------------------
DEPENDENCIES
------------------------
all files must be in the same directory in order to compile. 
------------------------
SUBMISSION INFORMATION
------------------------
CSCI1300 Spring 2022 Project 2
Author: Rodrigo Moleior
Recitation: 107 - Lucas Hayne
Date: April 22, 2022
------------------------
ABOUT THIS PROJECT
------------------------
This project is a game about a knight in a castle filled 
with enemies and loot.The goal is to explore every room in the castle.
You go around each room picking up items and fighting enemies.