#include "Map.h"
#include "Item.h"
#include "Weapon.h"
#include "Enemy.h"

#include <iostream>

using namespace std;

Map::Map(int rows, int cols, vector<Item> items_in, vector<Weapon> weapons_in,
            vector<Enemy> enemies_in, Player player_in) 

{
    num_rows = rows;
    num_cols = cols;
    items = items_in;
    weapons = weapons_in;
    enemies = enemies_in;
    player = player_in;
    
    // all rooms not visited by default
    for (int i = 0; i < rows; i++) 
    {
        visited.push_back(vector<bool>());
        for (int j = 0; j < cols; j++) 
        {
            visited.at(i).push_back(false);
        }
    }
}


void Map::displayMap() 
{
    
    for (int i = 0; i < visited.size(); i++) 
    {
        for (int j = 0; j < visited.at(i).size(); j++) 
        {
            if (i == player.getY() && j == player.getX()) 
            {
                // display a P for the player
                cout << "P ";
                continue;
            }
            // o for visited rooms, * for not yet visited
            if (visited.at(i).at(j)) cout << "o ";
            else cout << "* ";
        }
        cout << endl;
    }
}


// see if all rooms are visited.
// go through each room. If any room is false, return false.
// if all rooms are true, return true
bool Map::allRoomsVisited() 
{
    for (vector<bool> row: visited) 
    {
        for (bool room: row) 
        {
            if (!room) return false;
        }
    }

    return true;
}

void Map::visitRoom(int x, int y) 
{
    visited.at(y).at(x) = true;
}

void Map::addItem(Item item)
{
    items.push_back(item);
}

void Map::removeItem(Item item)
{
  vector<Item>::iterator it = items.begin();
    while (it < items.end()) 
    {
        if (it->getName() == item.getName()) {
            items.erase(it);
        }
    }
}

void Map::addWeapon(Weapon weapon)
{
    weapons.push_back(weapon);
}

void Map::removeWeapon(Weapon weapon)
{
    vector<Weapon>::iterator it = weapons.begin();
    while (it < weapons.end()) 
    {
        if (it->getName() == weapon.getName()) {
            weapons.erase(it);
        }
    }
}



vector<Item> Map::getItemsInRoom(int x, int y) 
{   
    vector<Item> result;

    for (int i = 0; i < items.size(); i++) //loop through items
    {
        Item item = items.at(i);
        if (item.getX() == x && item.getY() == y) 
        {
            result.push_back(items.at(i));
        }
    }

    return result;
}

vector<Weapon> Map::getWeaponsInRoom(int x, int y) 
{   
    vector<Weapon> result;

  

    for (int i = 0; i < weapons.size(); i++) //loop through weapons
    {
        Weapon weapon = weapons.at(i);
        if (weapon.getX() == x && weapon.getY() == y) 
        {
            result.push_back(weapons.at(i));
        }
    }

    return result;
}

vector<Enemy> Map::getEnemiesInRoom(int x, int y) 
{
    vector<Enemy> result;


    for (int i = 0; i < enemies.size(); i++) //loop through enemies
    {
        Enemy enemy = enemies.at(i);
        if (enemy.getX() == x && enemy.getY() == y) 
        {
            result.push_back(enemies.at(i));

        }
    }

    return result;
}