#include "HealthPotion.h"
#include <iostream>
#include <cstdlib>

using namespace std;

HealthPotion::HealthPotion(string name, int x, int y, int healthBoost_in) : Item(name, x, y)
{
    healthBoost = healthBoost_in;
}

void HealthPotion::useItem(Player player) 
{
    player.setHealth(player.getHealth() + healthBoost);
}