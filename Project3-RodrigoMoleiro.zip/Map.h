#ifndef MAP_H
#define MAP_H

#include <iostream>
#include <vector>
#include "Item.h"
#include "Weapon.h"
#include "Enemy.h"
#include "Player.h"
#include <algorithm>


using namespace std;


class Map 
{
    public:

        Map(int rows, int cols, vector<Item> items_in, vector<Weapon> weapons_in,
            vector<Enemy> enemies_in, Player player_in);

        void displayMap();
        bool allRoomsVisited();
        void visitRoom(int x, int y);

        // when player drops item
        void addItem(Item item);
        // when player picks up item
        void removeItem(Item item);
        
        // when player drops weapon
        void addWeapon(Weapon weapon);
        // when player picks up weapon
        void removeWeapon(Weapon weapon);

        // get all items in room w/ coords (x, y)
        vector<Item> getItemsInRoom(int x, int y);
        // get all weapons in room w/ coords (x, y)
        vector<Weapon> getWeaponsInRoom(int x, int y);
        // get all enemies in room w/ coords (x, y)
        vector<Enemy> getEnemiesInRoom(int x, int y);
    
    private:

        vector<Item> items;
        vector<Weapon> weapons;
        vector<Enemy> enemies;

        Player player;

        int num_rows;
        int num_cols;

        vector<vector<bool> > visited;

};

#endif