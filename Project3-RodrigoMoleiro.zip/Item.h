#ifndef ITEM_H
#define ITEM_H

#include <iostream>

using namespace std;


class Player;

class Item 
{
    public:

        virtual void useItem(Player player);

        Item();
        Item(string name_in, int x_in, int y_in);

        int getX();
        int getY();

        string getName();

        void setName(string);
        
        void setX(int x_in);
        void setY(int y_in);

    private:
        string name;

    protected:
        int x;
        int y;
    
    
};

#endif