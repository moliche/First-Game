#ifndef DEFENSEPOTION_H
#define DEFENSEPOTION_H

#include <iostream>
#include "Item.h"
#include "Player.h"

using namespace std;


class DefensePotion : public Item
{
    public:

        DefensePotion(string name_in, int x, int y, int defenseBoost);

        void useItem(Player player);

        

    private:
    
        int defenseBoost;



};

#endif