#ifndef PLAYER_H
#define PLAYER_H

#include <iostream>
#include "Enemy.h"
#include "Item.h"
#include "Weapon.h"
#include <vector>

using namespace std;


class Player
{
    public:

        Player();
        Player(int health_in, int defense_in, int attack_in);

        int getHealth();
        int getDefense();
        int getAttack();

        int getX();
        int getY();

        vector<Item> getItems();
        vector<Weapon> getWeapons();

        string getName();

        void setHealth(int);
        void setDefense(int);
        void setAttack(int);
        void setName(string );
        
        void setX(int);
        void setY(int);

        void attackEnemy(Enemy enemy);

        void equipRandomWeapon();

        void printItems();
        void printWeapons();

        void useRandomItem();

        void removeItem(Item);
        void removeWeapon(Weapon);
        
        void addItem(Item);
        void addWeapon(Weapon);

    private:
        vector<Item> items;
        vector<Weapon> weapons;
        
        Weapon * activeWeapon;

        int health;
        int defense;
        int attack = 10;
        
        int x;
        int y;

        string name;

    
};

#endif