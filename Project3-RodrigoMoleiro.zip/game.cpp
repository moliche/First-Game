#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <ctime>
#include "Map.h"
#include "Player.h"
#include "Enemy.h"
#include "Weapon.h"
#include "Item.h"
#include "HealthPotion.h"
#include "DefensePotion.h"
#include "AttackPotion.h"

using namespace std;

int main()
{
    srand(time(0));
    // 1) get player name
    // 2) init game
    // 3) main game loop:
    //  while player not dead and not all rooms visited:
    //      1) print player stats, map, description of anything inside of room, menu
    //      2) get player's choice
    //      3) handle player's choice
    // print finish screen

    string player_name = "";
    cout << "Enter your player name " << endl;
    getline(cin, player_name);
    
    // INIT GAME

    static const int ROWS = 12;
    static const int COLS = 12;

    // Health: 20-60
    // Defense: 0
    // Attack: 10-20
    Player player(rand() % 41 + 20, 0, rand() % 11 + 10);
    player.setName(player_name);

    vector<Item> items;
    vector<Weapon> weapons;
    vector<Enemy> enemies;

    // generate items
    for (int i = 0; i < (ROWS * COLS) / 3; i++) 
    {
        int itemType = rand() % 3;
        if (itemType == 0) 
        {
            // attack potion
            AttackPotion attackPotion( "Attack Potion " + to_string(i + 1), rand() % COLS, rand() % ROWS, rand() % 5 + 1);
            items.push_back(attackPotion);
        } else if (itemType == 1) 
        {
            // defense potion
            DefensePotion defensePotion( "Defense Potion " + to_string(i + 1), rand() % COLS, rand() % ROWS, rand() % 5 + 1);
            items.push_back(defensePotion);
        } else 
        {
            // health potion
            HealthPotion healthPotion( "Health Potion " + to_string(i + 1), rand() % COLS, rand() % ROWS, rand() % 5 + 1);
            items.push_back(healthPotion);
        }
    }

    // generate weapons
    string weaponNames[3] = {"Sword", "Bow", "Axe"};
    for (int i = 0; i < (ROWS * COLS) / 10; i++)
    {
        string weaponName = weaponNames[rand() % 3];
        Weapon weapon(rand() % COLS, rand() % ROWS, weaponName + to_string(i + 1), rand() % 21 + 5);
        weapons.push_back(weapon);
    }

    // generate enemies
    for (int i = 0; i < (ROWS * COLS) / 5; i++)
    {
        Enemy enemy(rand() % COLS, rand() % ROWS, rand() % 21 + 10, rand() % 6 + 5);
        enemies.push_back(enemy);
    }

    Map map(ROWS, COLS, items, weapons, enemies, player);

    // MAIN GAME LOOP
    while (player.getHealth() > 0 && !map.allRoomsVisited()) 
    {
        // PRINT STATS
        
        cout << "Player Name: " << player.getName() << endl;
        cout << "Health: " << player.getHealth() << endl;
        cout << "Defense: " << player.getDefense() << endl;

        // PRINT MAP
        map.displayMap();

        vector<Item> itemsInRoom = map.getItemsInRoom(player.getX(), player.getY());
        vector<Weapon> weaponsInRoom = map.getWeaponsInRoom(player.getX(), player.getY());

        for (Item item: itemsInRoom) 
        {
            cout << "There is a(n) " << item.getName() << " in the room." << endl;
        }
        for (Weapon weapon: weaponsInRoom) 
        {
            cout << "There is a(n) " << weapon.getName() << " in the room." << endl;
        }

        // IF ENEMY IN ROOM, GET INTO FIGHT
        vector<Enemy> enemies = map.getEnemiesInRoom(player.getX(), player.getY());

        for (Enemy enemy: enemies) 
        {
           enemy.setName("zombie");

            while(player.getHealth() > 0 && enemy.getHealth() > 0)
            {
                player.attackEnemy(enemy);
                if (enemy.getHealth() <= 0) 
                {
                    continue;
                }
                enemy.attackPlayer(player);
            }

            if (enemy.getHealth() <= 0) 
            {
                cout << enemy.getName() << " died." << endl;
            }
        }
        
        // skip printing menu if player died.
        if (player.getHealth() <= 0) continue;

        // PRINT MENU

        // 1. move
        //      1-4. direction
        // 2. open inventory
        //      1. use random item
        //      2. drop random item
        //      3. Back
        // 3. pickup all items/weapons in room
        // 4. open arsenal
        //      1. equip random weapon
        //      2. drop random weapon
        //      3.back
        // 5. quit

        cout << "1.Move\n2.Open Inventory\n3.Pickup Items and Weapons\n4.Open Arsenal\n5.Quit" << endl;
        

        // GET PLAYER CHOICE

        int playerChoice = 0;
        cin >> playerChoice;

        // HANDLE PLAYER CHOICE

        switch (playerChoice)
        {
            case 1:
            {
                // move:
                
                // PRINT MOVE OPTIONS

                cout << "1.up\n2.down\n3.left\n4.right" << endl;
                int moveOption = 0;

                // GET OPTION

                cin >> moveOption;

                // SEE IF VALID
                    //if moving up, and y == 0, ERROR
                    //if down, and y == ROWS, error
                    //if left and x == 0, error
                    //if right and x == COLS, error

                       /* if(player.getY() - 1 == 0)
                        {
                            cout << "Error: out of bounds" << endl;
                            break;
                        }
                        else if(player.getY() + 1 == 0)
                        {
                            cout << "Error: out of bounds" << endl;
                            break;
                        }
                        if(player.getX() - 1 == 0)
                        {
                            cout << "Error: out of bounds" << endl;
                            break;
                        }
                        else if(player.getX() + 1 == 0)
                        {
                            cout << "Error: out of bounds" << endl;
                            break;
                        }*/

                   

                        //if not error, move:
                        //up: y -= 1
                        //down: y += 1
                        // left: x -= 1
                        // right: x += 1

                        switch(moveOption)
                    {
                        case 1:
                        {
                            player.setY(player.getY() - 1);
                            break;
                        }
                        case 2:
                        {
                            player.setY(player.getY() + 1);
                            break;
                        }
                        case 3:
                        {
                            player.setX(player.getX() - 1);
                            break;  
                        }
                        case 4:
                        {
                            player.setX(player.getX() + 1);
                            break;
                        }
                    }

                        //Lastly, set the room to visited inside map: map.visitRoom(player.getX(), player.getY())
                        







                break;
            }

            case 2:
            {
                // open inventory:
                player.printItems();
                cout << "1.Use Random Item\n2.Drop Random Item\n3.Back" << endl;

                int inventoryChoice = 0;
                cin >> inventoryChoice;

                switch(inventoryChoice)
                {
                    case 1:
                        // use random item
                        player.useRandomItem();
                        break;
                    case 2:
                    {
                        // drop random item
                        vector<Item> playerItems = player.getItems();
                        if (playerItems.size() == 0)
                        {
                            cout << "Your inventory is empty." << endl;
                            break;
                        }

                        Item item = playerItems.at(rand() % playerItems.size());
                        map.addItem(item);
                        player.removeItem(item);
                        cout << item.getName() << " dropped." << endl;
                        break;
                    }

                    case 3:
                        // go back
                        continue;
                    default:
                        // What?
                        cout << "Beep boop! I'm just a dumb computer, I don't understand." << endl;
                        break;
                }

                break;
            }
                
            case 3:
            {
                // pickup items / weapons:
                for (int i = 0; i < itemsInRoom.size(); i++) {
                    Item item = itemsInRoom.at(i);
                    map.removeItem(item);
                    player.addItem(item);
                }

                for (int i = 0; i < weaponsInRoom.size(); i++) {
                    Weapon weapon = weaponsInRoom.at(i);
                    map.removeWeapon(weapon);
                    player.addWeapon(weapon);
                }
                break;
            }
                
            case 4:
            {
                player.printWeapons();
                // open arsenal:
                int arsenalChoice = 0;
                cout << "1.Equip random weapon\n2.Drop random weapon\n3.Back" << endl;
                cin >> arsenalChoice;

                switch(arsenalChoice)
                {
                    case 1:
                    {  //equip random weapon
                        
                        player.equipRandomWeapon();

                        break;
                    }   
                    case 2:
                    {   //drop random weapon

                        vector<Weapon> playerWeapons = player.getWeapons();
                        if (playerWeapons.size() == 0)
                        {
                            cout << "Your arsenal is empty.";
                            break;
                        }

                        Weapon weapon = playerWeapons.at(rand() % playerWeapons.size());
                        map.addWeapon(weapon);
                        player.removeWeapon(weapon);
                        cout << weapon.getName() << " dropped." << endl;
                        break;
                    }
                    case 3:
                        //go back to main menu
                        continue;
                    default:
                        // What?
                        cout << "Beep boop! I'm just a dumb computer, I don't understand." << endl;
                        break;
                }
                
                break;
            }
                
            case 5:
                // quit:
                cout << "Bye bye!" << endl;
                player.setHealth(0);
                return 0;
            default:
                // What?
                cout << "Beep boop! I'm just a dumb computer, I don't understand." << endl;
                break;
        }


    }

    // GAME OVER: PRINT WIN / LOSS


    if(player.getHealth() < 0)
    {
        cout << "You Died\n\nThanks for Playing!" << endl;

    }
    















    
}