#include "AttackPotion.h"
#include <iostream>
#include <cstdlib>

using namespace std;

AttackPotion::AttackPotion(string name, int x, int y, int attackBoost_in) : Item(name, x, y)
{
    attackBoost = attackBoost_in;
}

void AttackPotion::useItem(Player player) 
{
    player.setAttack(player.getAttack() + attackBoost);
}