#ifndef WEAPON_H
#define WEAPON_H

#include <iostream>
#include "Enemy.h"

using namespace std;




class Player;

class Weapon 
{
    public:

        Weapon();
        Weapon(int x_in, int y_in, string name_in, int damage_in);

        int getX();
        int getY();

        void setX(int x_in);
        void setY(int y_in);

        string getName();

        void setName(string);

        int getDamage();

    private:

        string name;

        int damage;

        int x;
        int y;

};

#endif