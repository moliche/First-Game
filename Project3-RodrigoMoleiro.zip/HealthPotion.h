#ifndef HEALTHPOTION_H
#define HEALTHPOTION_H

#include <iostream>
#include "Item.h"
#include "Player.h"

using namespace std;


class HealthPotion : public Item
{
    public:

        HealthPotion(string name_in, int x, int y, int healthBoost);
        void useItem(Player player);

        

    private:
    
        int healthBoost;



};

#endif