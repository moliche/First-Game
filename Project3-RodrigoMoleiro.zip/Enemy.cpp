#include "Enemy.h"
#include "Player.h"

#include <iostream>


using namespace std;


Enemy::Enemy()
{
    health = 50;
    attack = 10;
}


Enemy::Enemy(int x_in, int y_in, int health_in, int attack_in) 
{
    x = x_in;
    y = y_in;
    health = health_in;
    attack = attack_in;
}

int Enemy::getX()
{
    return x;
}
int Enemy::getY()
{
    return y;
}

int Enemy::getHealth()
{
    return health;
}

void Enemy::setHealth(int health_in)
{
    health = health_in;
}

void Enemy::setName(string name_in)
{
    name = name_in;
}

string Enemy::getName()
{
    return name;
}

int Enemy::getAttack()
{
    return attack;
}

void Enemy::attackPlayer(Player player)
{
    cout << name << " attacks " << player.getName() << endl;
    int enemyDamage = attack;

    // player blocks some of attack
    if (enemyDamage > player.getDefense())
     {
        // subtract player's defense from the damage
        int newDamage = enemyDamage - player.getDefense();
        // do damage, remove player defense
        player.setHealth(player.getHealth() - newDamage);
        player.setDefense(0);
        cout << "   - " << player.getDefense() << " defense" << endl;
        cout << "   - " << newDamage << " health" << endl;
    }
    // player blocks all of attack
    else 
    {
        // subtract defense
        player.setDefense(player.getDefense() - enemyDamage);
        cout << "   - " << enemyDamage << " defense" << endl;
    }
   
}