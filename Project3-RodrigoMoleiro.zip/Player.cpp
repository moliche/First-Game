#include <iostream>
#include "Player.h"
#include "Enemy.h"
#include "Item.h"
#include "Weapon.h"

using namespace std;

Player::Player() 
{
    Player(100, 10, 10);
}

Player::Player(int health_in, int defense_in, int attack_in)
{
    activeWeapon = NULL;
    health = health_in;
    defense = defense_in;
    attack = attack_in;
    x = 0;
    y = 0;
}

void Player::attackEnemy(Enemy enemy) 
{
    cout << name << " attacks " << enemy.getName() << endl;
    int playerDamage = attack;
    if (activeWeapon != NULL) 
    {
        playerDamage += 20;
    }
    enemy.setHealth(enemy.getHealth() - playerDamage);
    cout << name << " deals " << playerDamage << " damage." << endl;
}

void Player::equipRandomWeapon() 
{
    if (weapons.size() == 0) 
    {
        cout << "You have no weapons!" << endl;
        return;
    }

    activeWeapon = &weapons.at(rand() % weapons.size());
    cout << "Equiped " << activeWeapon->getName() << " with " << activeWeapon->getDamage() << " damage." << endl;
}

int Player::getHealth()
{
    return health;
}

int Player::getDefense()
{
    return defense;
}

int Player::getAttack()
{
    return attack;
}

string Player::getName()
{
    return name;
}

int Player::getX()
{
    return x;
}
int Player::getY()
{
    return y;
}

vector<Item> Player::getItems() {
    return items;
}

vector<Weapon> Player::getWeapons() {
    return weapons;
}



void Player::setHealth(int health_in)
{
    health = health_in;
}

void Player::setDefense(int defense_in)
{
    defense = defense_in;
}

void Player::setAttack(int attack_in)
{
    attack = attack_in;
}

void Player::setName(string name_in)
{
    name = name_in;
}

void Player::setX(int x_in)
{
    x = x_in;
}

void Player::setY(int y_in)
{
    y = y_in;
} 


void Player::printItems()
{
    if (items.size() == 0)
    {
        cout << "Your inventory is empty." << endl;
        return;
    }
    
    cout << "Your inventory:" << endl;
                
    for (int i = 0; i < items.size(); i++) 
    {
        cout << "   - " << items.at(i).getName() << endl;
    }
}

void Player::printWeapons()
{
    if (weapons.size() == 0)
    {
        cout << "Your arsenal is empty." << endl;
        return;
    }

    cout << "Your arsenal:" << endl;
    
        for (int i = 0; i < weapons.size(); i++) 
        {
            cout << "   - " << weapons.at(i).getName() << endl;
        }
}

void Player::useRandomItem()
{
    if (items.size() == 0)
    {
        cout << "Your inventory is empty." << endl;
        return;
    }

    Item item = items.at(rand() % items.size());
    cout << item.getName() << " used." << endl;
    item.useItem(*this);

    removeItem(item);
}

void Player::removeItem(Item item)
{
    vector<Item>::iterator it = items.begin();
    while (it < items.end()) 
    {
        if (it->getName() == item.getName()) {
            items.erase(it);
        }
    }
}

void Player::removeWeapon(Weapon weapon)
{
   vector<Weapon>::iterator it = weapons.begin();
    while (it < weapons.end()) 
    {
        if (it->getName() == weapon.getName()) {
            weapons.erase(it);
        }
    }
}

void Player::addItem(Item item)
{
    items.push_back(item);
}

void Player::addWeapon(Weapon weapon)
{
    weapons.push_back(weapon);
}